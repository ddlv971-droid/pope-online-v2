
import express from 'express';
import rateLimit from 'express-rate-limit';
import { optionalAuth } from '../middleware/auth.js';
import { withClient } from '../db/index.js';
import { sendMail } from '../services/mailer.js';
import { clamp, rejectIfSensitive } from '../services/rgpd.js';

const router = express.Router();

const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false
});

router.post('/request', optionalAuth, limiter, async (req, res) => {
  try {
    const email = String(req.body?.email || req.user?.email || '').trim();
    const objective = clamp(String(req.body?.subject || req.body?.objective || '').trim(), 1200);
    const expectations = clamp(String(req.body?.content || req.body?.expectations || '').trim(), 4000);
    const context = clamp(String(req.body?.context || '').trim(), 6000);

    if (!email || !email.includes('@')) return res.status(400).json({ error: 'invalid_email' });
    if (!objective) return res.status(400).json({ error: 'missing_objective' });
    if (!expectations) return res.status(400).json({ error: 'missing_expectations' });

    const combined = `${objective}\n${expectations}\n${context}`;
    if (rejectIfSensitive(combined)) return res.status(400).json({ error: 'sensitive_data' });

    const userId = req.user?.sub || null;
    const mailTo = process.env.MAIL_TO || 'contact@popeconsulting-group.com';

    const result = await withClient(async (client) => {
      await client.query('begin');

      if (userId) {
        const walletRes = await client.query('select * from wallets where user_id=$1 for update', [userId]);
        const wallet = walletRes.rows[0];
        if (wallet?.trial_expires_at && new Date(wallet.trial_expires_at).getTime() < Date.now()) {
          await client.query('update wallets set status=$2, updated_at=now() where user_id=$1', [userId, 'trial_expired']);
          await client.query('commit');
          return { ok: false, status: 402, body: { error: 'trial_expired' } };
        }
      }

      const ins = await client.query(
        `insert into expert_requests(user_id, email, objective, expectations, context)
         values($1,$2,$3,$4,$5)
         returning id`,
        [userId, email, objective, expectations, context]
      );
      const requestId = ins.rows[0].id;

      let usedTicket = false;
      let wallet = null;

      if (userId) {
        const w = await client.query('select * from wallets where user_id=$1 for update', [userId]);
        wallet = w.rows[0];
        const t = Number(wallet?.tickets_expert ?? 0);
        if (t > 0) {
          usedTicket = true;
          await client.query('update wallets set tickets_expert=tickets_expert-1, updated_at=now() where user_id=$1', [userId]);
        } else {
          const used = Number(wallet?.public_dossiers_used ?? 0);
          const limit = Number(wallet?.public_dossiers_limit ?? 1);
          if (used >= limit) {
            await client.query('rollback');
            return { ok: false, status: 402, body: { error: 'public_dossier_limit_reached' } };
          }
          await client.query('update wallets set public_dossiers_used=public_dossiers_used+1, updated_at=now() where user_id=$1', [userId]);
        }

        await client.query(
          'insert into usage_logs(user_id, kind, meta) values($1,$2,$3::jsonb)',
          [userId, 'expert_request', JSON.stringify({ requestId, usedTicket })]
        );
        const refresh = await client.query('select * from wallets where user_id=$1', [userId]);
        wallet = refresh.rows[0];
      }

      await client.query('commit');
      return { ok: true, requestId, usedTicket, wallet };
    });

    if (!result.ok) return res.status(result.status).json(result.body);

    await sendMail({
      to: mailTo,
      subject: `POPE Online — Demande EXPERT (${email})`,
      text:
`Nouvelle demande POPE EXPERT\n\nID: ${result.requestId}\nClient: ${email}\n\nObjectif:\n${objective}\n\nAttentes:\n${expectations}\n\nContexte:\n${context || '(non précisé)'}\n\nCouverture ticket expert: ${result.usedTicket ? 'OUI (décrémenté)' : 'NON (qualifié au titre du dossier)'}\n\n— POPE Online`,
    });

    return res.json({ ok: true, requestId: result.requestId, usedTicket: result.usedTicket, wallet: result.wallet });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server_error', detail: String(e?.message || e) });
  }
});

export default router;
